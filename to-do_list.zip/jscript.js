function addTask() {
    var taskInput = document.getElementById("taskInput");
    var deadlineInput = document.getElementById("deadlineInput");
    var priorityInput = document.getElementById("priorityInput");

    var task = taskInput.value;
    var deadline = deadlineInput.value;
    var priority = priorityInput.value;

///error handling
    if (task === "" || deadline === "") {
      alert("Please enter a task and deadline!");
      return;
    }
/// assigning position in tables
    var table = document.getElementById("todoTable");
    var row = table.insertRow(-1);

    var taskCell = row.insertCell(0);
    var deadlineCell = row.insertCell(1);
    var priorityCell = row.insertCell(2);
    var actionCell = row.insertCell(3);

///assigning values from html in table
    taskCell.innerHTML = task;
    deadlineCell.innerHTML = deadline;
    priorityCell.innerHTML = priority;
    actionCell.innerHTML = "<button onclick='removeTask(this)'>Delete</button>";

///default values-
    taskInput.value = "";
    deadlineInput.value = "";
    priorityInput.value = "low";
  }
///delete task button
  function removeTask(button) {
    var row = button.parentNode.parentNode;
    var table = row.parentNode;
    table.deleteRow(row.rowIndex);
  }